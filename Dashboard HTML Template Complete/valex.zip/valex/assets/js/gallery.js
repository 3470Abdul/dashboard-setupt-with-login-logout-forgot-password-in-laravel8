/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!****************************************!*\
  !*** ./resources/assets/js/gallery.js ***!
  \****************************************/
(function ($) {
  "use strict";

  $('#lightgallery').lightGallery();
  $('#video-gallery').lightGallery();
})(jQuery);
/******/ })()
;