/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!*******************************************!*\
  !*** ./resources/assets/js/summernote.js ***!
  \*******************************************/
jQuery(function (e) {
  'use strict';

  $(document).ready(function () {
    $('#summernote').summernote();
  });
});
/******/ })()
;