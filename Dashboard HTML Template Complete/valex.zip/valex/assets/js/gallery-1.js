/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!******************************************!*\
  !*** ./resources/assets/js/gallery-1.js ***!
  \******************************************/
(function ($) {
  document.addEventListener('DOMContentLoaded', function () {
    new SmartPhoto(".js-img-viewer", {
      resizeStyle: 'fit'
    });
  });
})(jQuery);
/******/ })()
;